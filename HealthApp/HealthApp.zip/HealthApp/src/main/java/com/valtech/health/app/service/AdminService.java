package com.valtech.health.app.service;

import com.valtech.health.app.entity.Admin;

public interface AdminService {

	/* This method creates Admin */
	Admin createAdmin(Admin ad);

}
